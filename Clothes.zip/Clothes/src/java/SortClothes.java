import clothes.*;
import clothesFeatures.PantsLengths;
import clothesFeatures.States;
import controller.StorageController;
import utils.FileHandler;

import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;

public class SortClothes {
    public static void main(String[] args) throws IOException {
        //FileHandler.scanFile(sourceDirectory);

        FileHandler fileHandler = new FileHandler();
        String sourceDirectory = fileHandler.directory();
        //System.out.println(fileHandler.scanSocks(sourceDirectory));
        //System.out.println(fileHandler.socksList(sourceDirectory, "zokni").get(0).getName());
        //System.out.println(fileHandler.socksList(sourceDirectory, "zokni").get(0).getState());
        //fileHandler.loadData();
        //fileHandler.loadLists(sourceDirectory);
        System.out.println(fileHandler.coatsList(sourceDirectory, "kabát").get(0).getCategory());
        System.out.println(fileHandler.shirtList(sourceDirectory, "ing").get(0).getLongSleeve());

        Coat coats = new Coat();
        //coats.getCoatStates();
        //coats.sortByState(3);

//        System.out.println(fileHandler.clothesList(sourceDirectory).get(3).getName());
//        System.out.println(fileHandler.clothesList(sourceDirectory).get(3).getCategory());
//
//        System.out.println(fileHandler.clothesList(sourceDirectory).get(43).getName());
//
//        System.out.println(fileHandler.clothesList(sourceDirectory).get(67).getName());

        //coats.countCoats();
        //coats.countByState();

        System.out.println("*****************************");
        //ClothesCategories clothesCategories = new ClothesCategories();
        //clothesCategories.countByStateClothes();
        States state = States.THROW;
        //System.out.println(state);

        PantsLengths pantsLengths = PantsLengths.KNEE;
        //System.out.println(pantsLengths); //KNEE
        //System.out.println(pantsLengths.getName()); //KNEE
        //System.out.println(pantsLengths.getMyType()); // for fall and spring
        fileHandler.shirtList(fileHandler.directory(), "ing");

        StorageController storageController = new StorageController();

        //storageController.countByStateClothes();
//        storageController.countTShirts();
//        storageController.countTShirtsByState();
//        storageController.decrementtShirts(storageController.countTShirtsByState());
//        System.out.println("*******************************");
//        storageController.counttShirtsByCategoryAndState();

        System.out.println(fileHandler.socksList(sourceDirectory, "zokni").get(0).getState());
        System.out.println(fileHandler.socksList(sourceDirectory, "zokni").get(0).getCategory());
    }
}