package clothesFeatures;

public enum SocksTypes {
    SECRET("titokzokni"),
    NORMAL("normál"),
    KNEE("térdzokni");

    String myType;

    SocksTypes(String myType){
        this.myType = myType;
    }

    public String getName(){
        return this.name();
    }

    public String getMyType(){
        return myType;
    }

}
