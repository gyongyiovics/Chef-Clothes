package clothesFeatures;

public enum States {
    GIVE,
    THROW,
    KEEP
}

//notes: returns the name! -> THROW, GIVE, KEEP