package clothesFeatures;

public enum PantsLengths {

    //comma and then semicolon....
    SHORT("hot pants"),
    KNEE("for fall and spring"),
    LONG("only for winter");

    private String myType;

    PantsLengths(String myType){
        this.myType = myType;
    }

    public String getName(){
        return this.name();
    }

    public String getMyType(){
        return myType;
    }

}
