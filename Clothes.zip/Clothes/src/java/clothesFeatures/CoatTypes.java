package clothesFeatures;

public enum CoatTypes {
    RAINCOAT, FALL, WINTER
}
