package controller;

import clothes.ClothesCategories;
import clothes.TShirt;
import utils.FileHandler;

import java.io.IOException;
import java.util.List;

public class StorageController {

    FileHandler fileHandler = new FileHandler();
    String sourceDirectory = fileHandler.directory();

    //TODO: public methods for each category!
    //clothesCategories
    public void countByStateClothes() throws IOException {
        List<ClothesCategories> clothesCategories = fileHandler.clothesList(sourceDirectory);
        int countGoods = 0;
        int countBads = 0;
        int countForCharity = 0;

        for (ClothesCategories clothes : clothesCategories) {
            if(clothes.getState() == 5){
                countBads++;
                //System.out.println("How many clothes do I throw out: " + countBads);
            }   else if (clothes.getState() == 3 || clothes.getState() == 4) {
                countForCharity++;
                //System.out.println("How many clothes do I give away: " + countForCharity);
            } else if (clothes.getState() == 1 || clothes.getState() == 2) {
                countGoods++;
                //System.out.println("How many clothes do I keep: " + countGoods);
            }
        }
        System.out.println("How many clothes do I throw out: " + countBads);
        System.out.println("How many clothes do I give away: " + countForCharity);
        System.out.println("How many clothes do I keep: " + countGoods);
    }


}
