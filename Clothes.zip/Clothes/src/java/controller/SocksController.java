package controller;

public class SocksController {
}
