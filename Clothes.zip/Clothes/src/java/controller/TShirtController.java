package controller;

import clothes.TShirt;
import utils.FileHandler;

import java.io.IOException;
import java.util.List;

public class TShirtController {

    FileHandler fileHandler = new FileHandler();
    String sourceDirectory = fileHandler.directory();

    public void countTShirts() throws IOException {
        TShirt tShirt = new TShirt();
        List<TShirt> tShirtList = fileHandler.tShirtList(sourceDirectory, "póló");
        System.out.println("How many " + tShirt.getName() + " do I have? : " + tShirtList.size());
        int countMultiChrome = 0;
        int countMonoChrome = 0;

        for (TShirt tshirt : tShirtList) {
            //does not read anything - even if it is Bool or String --> it reads the String from the tShirtList
            //System.out.println(tshirt.getMultiChrome());
            if(tshirt.getMultiChrome().equals("igen")) {
                countMonoChrome++;
            } else {
                countMultiChrome++;
            }
        }
        System.out.println("How many colored: " + countMultiChrome);
        System.out.println("Hom many with one color: " + countMonoChrome);
    }

    public int countTShirtsByState() throws IOException {
        TShirt tShirt = new TShirt();

        List<TShirt> tShirtList = fileHandler.tShirtList(sourceDirectory, "póló");
        int countGoods = 0;
        int countBads = 0;
        int countForCharity = 0;

        for (TShirt polo : tShirtList) {
            if(polo.getState() == 5){
                countBads++;
            }   else if (polo.getState() == 3 || polo.getState() == 4) {
                countForCharity++;
            } else if (polo.getState() == 1 || polo.getState() == 2) {
                countGoods++;
            }
        }
        System.out.println("How many " + tShirt.getName() + " do I throw out: " + countBads);
        System.out.println("How many " + tShirt.getName() + " do I give away: " + countForCharity);
        System.out.println("How many " + tShirt.getName() + " do I keep: " + countGoods);

        return countGoods;
    }

    //how many do I keep, throw out or give away?
    public void counttShirtsByCategoryAndState() throws IOException {
        TShirt tShirt = new TShirt();

        List<TShirt> tShirtList = fileHandler.tShirtList(sourceDirectory, "póló");
        int countGoods = 0;
        int countGoodsColored = 0;
        int countBads = 0;
        int countBadsColored = 0;
        int countForCharity = 0;
        int countForCharityColored = 0;

        for (TShirt polo : tShirtList) {
            Boolean isTrue = polo.getMultiChrome().equals("igen");
            if(polo.getState() == 5 && isTrue){
                countBadsColored++;
            } else if(polo.getState() == 5 && !isTrue){
                countBads++;
            } else if((polo.getState() == 3 || polo.getState() == 4) && isTrue){
                countForCharityColored++;
            } else if((polo.getState() == 3 || polo.getState() == 4) && !isTrue){
                countForCharity++;
            } else if((polo.getState() == 1 || polo.getState() == 2) && isTrue){
                countGoodsColored++;
            } else if((polo.getState() == 1 || polo.getState() == 2) && !isTrue){
                countGoods++;
            }
        }

        System.out.println("How many colored tShirt do I throw out: " + countBadsColored);
        System.out.println("How many " + tShirt.getName() + " do I throw out: " + countBads);
        System.out.println("How many colored tShirt do I give away: " + countForCharityColored);
        System.out.println("How many " + tShirt.getName() + " do I give away: " + countForCharity);
        System.out.println("How many colored tShirt do I keep: " + countGoodsColored);
        System.out.println("How many " + tShirt.getName() + " do I keep: " + countGoods);

    }

    public void decrementtShirts(int countGoods){
        System.out.println("*********************************");
        System.out.print("That many tShirts I keep: ");
        System.out.println(countGoods);
    }
}
