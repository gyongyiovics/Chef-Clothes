package utils;

import clothes.*;
import clothesFeatures.PantsLengths;
import clothesFeatures.SocksTypes;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * read files here, and return ArrayLists of data
 * TShirts -> name, category, state, color, isMultiChrome
 * Shirts -> name, category, state, isLongSleeve
 * Pants -> name, category, state, length
 * Coat -> name, category, state, type
 * Shoes -> name, category, state, size
 * Socks -> name, category, state, type
 *
 * Scanner, Buffered, Stream
 */

public class FileHandler {
    private static final String sourceDirectory = "src/resources/clothes.txt";

    public String directory(){
        return sourceDirectory;
    }



    private final List<Socks> socks = new ArrayList<>();
    private final List<Coat> coats = new ArrayList<>();
    private final List<Shoes> shoes = new ArrayList<>();
    private final List<TShirt> tShirts = new ArrayList<>();
    private final List<Shirt> shirts = new ArrayList<>();
    private final List<Pants> pants = new ArrayList<>();

    public static void scanFile(String fileName) throws IOException {
        File file = new File(fileName);
        Scanner sc;
        if (file.exists()) {
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                System.out.println(line);
            }
        }
    }

    /**
     * fill up arrays depending on the first word ->
     * if firstWord is "zokni", add the line to the socks Array, and so on...
     */

    public void loadData(){
        try {
            String source = sourceDirectory;
            System.out.println(socksList(source, "zokni").get(0).getCategory());
            System.out.println();
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    public ArrayList<String> scanSocks(String fileName) throws IOException {
        ArrayList<String> readSocks = new ArrayList<>();
        File file = new File(fileName);
        Scanner sc;
        if (file.exists()) {
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                //System.out.println(line);
                if (line.contains("zokni")) {
                    readSocks.add(line);
                }
            }
        }
        return readSocks;
    }

    //create objects by class depending on the name: zokni, póló, etc...
    //TODO: replace the parameter with the CONST fileName, and call all the clothes lines depending on the name
    public void loadLists(String fileName) throws IOException {
        BufferedReader bufferedReader = bufferedReader(fileName);
        for (String line; (line = bufferedReader.readLine()) != null; ) {
            String[] parts = line.split(",");
            //System.out.println(parts[0]);
            //does not work with the parts[0] == "cipő" statement, but rather with line.contains("zokni") statement!
            //looks better with a switch -case?
            if (fileName.equals(sourceDirectory) && line.contains("zokni")) {
                socks.add(new Socks(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
                System.out.println(socks.get(0).getName());
                System.out.println(parts[0]);
                break;
            } else if (fileName.equals(sourceDirectory) && line.contains("cipő")) {
                shoes.add(new Shoes(parts[0], parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
                System.out.println(shoes.get(0).getName());
                break;
            } else if (fileName.equals(sourceDirectory) && line.contains("kabát")) {
                coats.add(new Coat(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
                System.out.println(coats.get(0).getName());
                break;
            } else if (fileName.equals(sourceDirectory) && line.contains("nadrág")) {
                pants.add(new Pants(parts[0], parts[1], Integer.parseInt(parts[2]), PantsLengths.valueOf(parts[3])));
            } else if (fileName.equals(sourceDirectory) && line.contains("ing")) {
                shirts.add(new Shirt(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
            } else if (fileName.equals(sourceDirectory) && line.contains("póló")) {
                tShirts.add(new TShirt(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4]));
            }
        }
    }

    //private bufferedReader
    private BufferedReader bufferedReader(String fileName) throws FileNotFoundException {
        FileReader fileReader = new FileReader(fileName);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        return bufferedReader;
    }

    //socks
    public List<Socks> socksList(String fileName, String name) throws IOException {
        List<Socks> socksList= new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            if(line.contains(name)){
                socksList.add(new Socks(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
            }
        }
        return socksList;
    }

    //shoes
    public List<Shoes> shoesList(String fileName, String name) throws IOException {
        List<Shoes> socksList= new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            if(line.contains(name)){
                socksList.add(new Shoes(parts[0], parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3])));
            }
        }
        return socksList;
    }

    //pants
    public List<Pants> pantsList(String fileName, String name) throws IOException {
        List<Pants> pantsList= new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            if(line.contains(name)){
                pantsList.add(new Pants(parts[0], parts[1], Integer.parseInt(parts[2]), PantsLengths.valueOf(parts[3])));
            }
        }
        return pantsList;
    }

    //shirts
    public List<Shirt> shirtList(String fileName, String name) throws IOException {
        List<Shirt> shirtList= new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            if(line.contains(name)){
                shirtList.add(new Shirt(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
            }
        }
        Shirt newShirts = new Shirt();
        /*System.out.println("kiskutya");
        //ez itt azért null, mert itt ad neki értékeket, nem a Shirt class-ban!
        System.out.println(newShirts.getLongSleeve());
        */
        return shirtList;
    }

    //T-shirts
    public List<TShirt> tShirtList(String fileName, String name) throws IOException {
        List<TShirt> tShirtList= new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            if(line.contains(name)){
                tShirtList.add(new TShirt(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], parts[4]));
            }
        }
        return tShirtList;
    }

    //coats
    public List<Coat> coatsList(String fileName, String name) throws IOException {
        List<Coat> coatsList = new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            if(line.contains(name)){
                coatsList.add(new Coat(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
            }
        }
        return coatsList;
    }

    //clothesCategories -> the parentClass
    public List<ClothesCategories> clothesList(String fileName) throws IOException {
        List<ClothesCategories> clothesList = new ArrayList<>();
        BufferedReader reader = bufferedReader(fileName);
        for (String line; (line = reader.readLine()) != null; ) {
            String[] parts = line.split(",");
            clothesList.add(new Coat(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]));
        }
        return clothesList;
    }

}