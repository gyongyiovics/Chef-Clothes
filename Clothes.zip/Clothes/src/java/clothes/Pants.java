package clothes;

import clothesFeatures.PantsLengths;

public class Pants extends ClothesCategories {
    private PantsLengths length;

    public Pants(String name, String category, int state, PantsLengths length) {
        super(name, category, state);
        this.length = length;
    }
}
