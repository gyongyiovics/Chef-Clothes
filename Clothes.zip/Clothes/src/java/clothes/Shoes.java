package clothes;

public class Shoes extends ClothesCategories {
    int size;

    public Shoes(String name, String category, int state, int size) {
        super(name, category, state);
        this.size = size;
    }
}
