package clothes;

import utils.FileHandler;

import java.io.IOException;
import java.util.List;

public class TShirt extends ClothesCategories {
    String color;
    String isMultiChrome;

    public TShirt(){
        this.name = "tShirts";
    };

    public TShirt(String name, String category, int state, String color, String isMultiChrome) {
        super(name, category, state);
        this.color = color;
        this.isMultiChrome = isMultiChrome;
    }

    public String getColor() {
        return color;
    }

    public String getMultiChrome() {
 //is it worth doing it in string? Yup
        /*if(isMultiChrome.contains("igen")){
            return true;
        }
        return false;*/
        return isMultiChrome;
    }
}
