package clothes;

public class ClothesCategories {
    String name;
    String category;
    int state;

    public ClothesCategories(){}

    public ClothesCategories(String name, String category, int state) {
        this.name = name;
        this.category = category;
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public int getState() {
        return state;
    }

}
