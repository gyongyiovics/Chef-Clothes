package clothes;

import utils.FileHandler;

import java.io.IOException;
import java.util.List;

public class Shirt extends ClothesCategories {
    String isLongSleeve;

    public Shirt(){};

    public Shirt(String name, String category, int state, String isLongSleeve) {
        super(name, category, state);
        this.isLongSleeve = isLongSleeve;
    }

    //TODO: ez igy nem olvas be semmit
    public String getLongSleeve() {
        /*if(isLongSleeve.equals("igen")){
            return true;
        }
        return false;*/
        return isLongSleeve;
    }

    FileHandler fileHandler = new FileHandler();
    public final String sourceDirectory = "src/resources/clothes.txt";

    public void countShirts() throws IOException {
        List<Shirt> shirtList = fileHandler.shirtList(sourceDirectory, "ing");
        System.out.println(shirtList.size());
    }

    public void countByState() throws IOException {
        List<Shirt> shirtList = fileHandler.shirtList(sourceDirectory, "ing");
        int countGoods = 0;
        int countBads = 0;
        int countForCharity = 0;

        for (Shirt ing: shirtList) {
            if(ing.getState() == 5){
                countBads++;
                //System.out.println("How many clothes do I throw out: " + countBads);
            }   else if (ing.getState() == 3 || ing.getState() == 4) {
                countForCharity++;
                //System.out.println("How many clothes do I give away: " + countForCharity);
            } else if (ing.getState() == 1 || ing.getState() == 2) {
                countGoods++;
                //System.out.println("How many clothes do I keep: " + countGoods);
            }
        }
        System.out.println("How many coats do I throw out: " + countBads);
        System.out.println("How many coats do I give away: " + countForCharity);
        System.out.println("How many coats do I keep: " + countGoods);
    }

}
