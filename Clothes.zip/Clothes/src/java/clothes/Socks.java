package clothes;

import clothesFeatures.SocksTypes;

public class Socks extends ClothesCategories {
    String socksTypes;
    //public Socks(){};

    public Socks(String name, String category, int state, String socksTypes) {
        super(name, category, state);
        this.socksTypes = socksTypes;
    }
    /*public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }*/
}
