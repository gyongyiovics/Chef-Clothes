package clothes;

import utils.FileHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//enum types {RAINCOAT, FALL, WINTER};

public class Coat extends ClothesCategories {
    String type;

    //enum types {RAINCOAT, FALL, WINTER}

    public Coat(){}

    public Coat(String name, String category, int state, String type) {
        super(name, category, state);
        this.type = type;
    }
    //enum with switch case

    //collection of coat categories, and states
    FileHandler fileHandler = new FileHandler();
    public final String sourceDirectory = fileHandler.directory();
    public void getCoatStates() throws IOException {
        List<Coat> coatsList = fileHandler.coatsList(sourceDirectory, "kabát");
        HashMap<String, String > mapping = new HashMap<>();
        for (Coat coat : coatsList) {
            System.out.println(coat.getState());
        }
        //System.out.println(fileHandler.coatsList(sourceDirectory, "kabát").get(0).getCategory());

        for (Coat coat : coatsList) {
            mapping.put(coat.getName(), String.valueOf(coat.getState()));
            //map of maps!!
            //System.out.println(mapping.keySet());
            System.out.println(mapping);
        }
    }

    public List<String> sortByState(int state) {
        List<String> throwOut = new ArrayList<>();
        List<String> keep = new ArrayList<>();
        List<String> giveAway = new ArrayList<>();
        List<String> coatList;

        if (state <= 0 || state > 5) {
            System.out.println("Guess I have categorize this one...");
            throwOut.add(this.getName());
            coatList = throwOut;
        } else if (state == 1 || state == 2) {
            System.out.println("I am keeping it. Yay!");
            keep.add(this.getName());
            coatList = keep;
        } else if (state == 1 || state == 2) {
            System.out.println("Give them to charity");
            giveAway.add(this.getName());
            coatList = giveAway;
        } else {
            System.out.println("Throwing it out");
            throwOut.add(this.getName());
            coatList = throwOut;
        }
        return coatList;
    }

    //counter
    public void countCoats() throws IOException {
        List<Coat> coatsList = fileHandler.coatsList(sourceDirectory, "kabát");
        System.out.println(coatsList.size());
    }

enum types {RAINCOAT, FALL, WINTER};
    public void countByState() throws IOException {
        List<Coat> coatsList = fileHandler.coatsList(sourceDirectory, "kabát");
        int countGoods = 0;
        int countBads = 0;
        int countForCharity = 0;

        for (Coat coat: coatsList) {
            if(coat.getState() == 5){
                countBads++;
                //System.out.println("How many clothes do I throw out: " + countBads);
            }   else if (coat.getState() == 3 || coat.getState() == 4) {
                countForCharity++;
                //System.out.println("How many clothes do I give away: " + countForCharity);
            } else if (coat.getState() == 1 || coat.getState() == 2) {
                countGoods++;
                //System.out.println("How many clothes do I keep: " + countGoods);
            }
        }
        System.out.println("How many coats do I throw out: " + countBads);
        System.out.println("How many coats do I give away: " + countForCharity);
        System.out.println("How many coats do I keep: " + countGoods);
    }

}
