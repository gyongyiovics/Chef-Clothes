package Kitchen.Tools;

public class ActionTools {

    public String name;
    public boolean isClean;
    public boolean hasContent;

    public ActionTools(){}

    public String isClean() {
        return this.isClean ? "washed" : "dirty";
    }

    public void setClean(boolean clean) {
        isClean = clean;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isHasContent() {
        return hasContent;
    }

    public void setHasContent(boolean hasContent) {
        this.hasContent = hasContent;
    }
}
