package Kitchen.Tools.ActionToolsElements;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Pan extends ActionTools {

    public Pan(){
        this.name = "Pan";
        this.isClean = true;
        this.hasContent = false;
    }



    public void putThePan (Ingredients[] array) {
        for (Ingredients ingredients : array) {
            if (ingredients.states.equals("on the board") && ingredients.needToFry && !ingredients.needToCut || ingredients.states.equals("beaten up") && ingredients.needToFry
                    || ingredients.states.equals("breaded") && ingredients.needToFry || ingredients.states.equals("raw") && ingredients.needToFry && ingredients.needToHeat) {
                ingredients.states = "in the pan";
                this.hasContent = true;
                this.isClean = false;
                System.out.println("The " + ingredients.name + " is " + ingredients.states + ".");
            }
        }
    }

    public void putThePan (Flavoring[] array) {
        for (Flavoring flavoring : array) {
            if (flavoring.states.equals("in the container") && flavoring.isItForFrying) {
                flavoring.states = "in the pan";
                System.out.println("The content of the " + this.name + " are seasoned.");
                break;
            }
        }
    }

}