package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class BakingTin extends ActionTools {

    public BakingTin(){
        this.name = "Baking Tin";
        this.isClean = true;
        this.hasContent = false;
    }

    public void putTheBakingTin(Ingredients[] array){
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("on the board") && array[i].needToBake  && !array[i].needToCut || array[i].states.equals("beaten up") && array[i].needToBake ||
                    array[i].states.equals("in the bowl") && array[i].needToBake) {
                array[i].states = "in the baking tin";
                this.isClean = false;
                System.out.println("The " + array[i].name + " is " + array[i].states + ".");
            }
        }
    }
}
