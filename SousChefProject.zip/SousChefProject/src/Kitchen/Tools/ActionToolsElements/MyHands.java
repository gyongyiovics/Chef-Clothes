package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class MyHands extends ActionTools {

    public MyHands(){
        this.name = "My Hands";
        this.isClean = false;
        this.hasContent = false;
    }

    public void wash() {
        if (!this.isClean) {
            this.isClean = true;
            System.out.println(this.name + " is " + isClean() + ".");
        }
    }

    public void clean(ActionTools actionTools){
        if (!actionTools.isClean) {
            actionTools.setClean(true);
            System.out.println("The " + actionTools.name + " is " + actionTools.isClean() + ".");
        }
    }

    public void crack(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("unbroken")) {
                array[i].states = "cracked";
                System.out.println("The state of " + array[i].name + " is now " + array[i].states + ".");
            }
        }
    }

    public void coatWithBreadcrumbs(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].needToCoatWithBreadcrumbs && array[i].states.equals("on the board")) {
                array[i].needToCoatWithBreadcrumbs = false;
                array[i].states = "breaded";
                this.isClean = false;
                System.out.println(array[i].name + " is now " + array[i].isNeedToCoatWithBreadcrumbs() + ".");
            }
        }
    }

}
