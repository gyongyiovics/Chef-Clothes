package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Peeler extends ActionTools {

    public Peeler(){
        super();
        this.name = "Peeler";
        this.isClean = true;
        this.hasContent = false;
    }

    public void peel(Ingredients[] array) {
        int counter = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i].needToPeel) {
                array[i].needToPeel = false;
                System.out.println("The " + array[i].name + " is now " + array[i].isNeedToPeel() + ".");
                counter ++;
            }
        }
        if( counter != 0){
            this.isClean = false;
        }
    }
}
