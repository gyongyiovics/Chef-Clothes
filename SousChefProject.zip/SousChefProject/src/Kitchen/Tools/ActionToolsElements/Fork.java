package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Fork extends ActionTools {

    public Fork() {
        this.name = "Fork";
        this.isClean = true;
        this.hasContent = false;
    }

    public void beatUp(Ingredients[] array) {
        for (int i = 0; i < array.length; i++){
            if (array[i].states.equals("in the bowl") && array[i].needToBeatUp) {
                array[i].states = "beaten up";
                array[i].needToBeatUp = false;
                this.isClean = false;
                System.out.println("The " + array[i].name + " is " + array[i].states + ".");

            }
        }
    }

}
