package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Stove extends ActionTools {

    public Stove(){
        this.name = "Stove";
        this.isClean = true;
        this.hasContent = false;
    }

    public void cook(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("in the pot") && array[i].needToCook) {
                array[i].states = "cooked";
                array[i].needToCook = false;
                this.isClean = false;
                if(array[i].getType().equals("Liquid") && array[i].needToHeat) {
                    System.out.println("The " + array[i].name + " is boiled.");
                }else{
                    System.out.println("The " + array[i].name + " is " + array[i].states + ".");
                }
            }
        }
    }

    public void fry(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("in the pan") && array[i].needToFry) {
                array[i].states = "fried";
                array[i].needToFry = false;
                this.isClean = false;
                if(array[i].getType().equals("Fat")) {
                    System.out.println("The " + array[i].name + " has been used up.");
                }else{
                    System.out.println("The " + array[i].name + " is " + array[i].states + ".");
                }
            }
        }
    }

    public void bake(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("in the baking tin") && array[i].needToBake) {
                array[i].states = "baked";
                array[i].needToBake = false;
                this.isClean = false;
                System.out.println("The " + array[i].name + " is " + array[i].states + ".");
            }
        }
    }

}
