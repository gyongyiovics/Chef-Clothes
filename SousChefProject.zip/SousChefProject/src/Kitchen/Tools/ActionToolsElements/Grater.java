package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Grater extends ActionTools {

    public Grater(){
        this.name = "Grater";
        this.isClean = true;
        this.hasContent = false;
    }

    public void grate(Ingredients[] array) {
        int counter = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i].needToGrate) {
                array[i].needToGrate = false;
                System.out.println("The " + array[i].name + " is " + array[i].isNeedToGrate() + ".");
                counter ++;
            }
        }
        if( counter != 0){
            this.isClean = false;
        }
    }

}
