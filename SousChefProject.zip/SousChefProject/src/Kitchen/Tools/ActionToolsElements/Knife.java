package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Knife extends ActionTools {

    public Knife(){
        this.name = "Knife";
        this.isClean = true;
        this.hasContent = false;
    }

    public void cut(Ingredients[] array) {
        int counter = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i].needToCut && array[i].states.equals("on the board")) {
                array[i].needToCut = false;
                System.out.println("The " + array[i].name + " is " + array[i].isNeedToCut() + ".");
                counter ++;
            }
        }
        if( counter != 0){
            this.isClean = false;
        }
    }
}