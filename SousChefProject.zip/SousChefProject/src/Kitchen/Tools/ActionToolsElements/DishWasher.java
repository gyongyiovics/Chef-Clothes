package Kitchen.Tools.ActionToolsElements;
import Kitchen.Tools.ActionTools;


public class DishWasher {

    public void wash(ActionTools actionTools) {
        if (!actionTools.isClean) {
            actionTools.isClean = true;
            System.out.println("The " + actionTools.getName() + " is " + actionTools.isClean() + ".");
        }
    }

    public void wash(ActionTools[] array){
        for (int i = 0; i < array.length; i++) {
            if (!array[i].isClean) {
                array[i].isClean = true;
                System.out.println("The " + array[i].getName() + " is " + array[i].isClean() + ".");
            }
        }
    }
}