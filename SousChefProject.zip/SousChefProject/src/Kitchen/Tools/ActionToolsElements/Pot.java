package Kitchen.Tools.ActionToolsElements;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Pot extends ActionTools {

    public Pot(){
        this.name = "Pot";
        this.isClean = true;
        this.hasContent = false;
    }

    public void putThePot (Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("on the board") && array[i].needToCook  && !array[i].needToCut || array[i].states.equals("beaten up") && array[i].needToCook ||
                    array[i].states.equals("raw") && array[i].needToCook  && array[i].needToHeat ||
                    array[i].states.equals("raw") && array[i].needToCook  && array[i].type.equals("Pasta")) {
                array[i].states = "in the pot";
                this.hasContent = true;
                this.isClean = false;
                System.out.println("The " + array[i].name + " is now " + array[i].states + ".");
            }
        }
    }

    public void putThePot (Flavoring[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("in the container") && array[i].isItForCooking) {
                array[i].states = "in the pot";
                System.out.println("The content of the " + this.name + " are seasoned.");
                break;
            }
        }
    }
}
