package Kitchen.Tools.ActionToolsElements;

import Kitchen.Tools.ActionTools;

public class WoodenSpoon extends ActionTools {

    public WoodenSpoon(){
        this.name = "Wooden Spoon";
        this.isClean = true;
        this.hasContent = false;
    }

    public void mix(ActionTools actionTools) {
        if (this.isClean && actionTools.hasContent) {
            System.out.println("The content of the " + actionTools.name + " is mixed.");
            this.isClean = false;
        }
    }
}
