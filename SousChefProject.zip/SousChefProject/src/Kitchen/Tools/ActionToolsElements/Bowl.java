package Kitchen.Tools.ActionToolsElements;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Bowl extends ActionTools {

    public Bowl(){
        this.name = "Bowl";
        this.isClean = true;
        this.hasContent = false;
    }

    public void putTheBowl(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("cracked") && array[i].needToBeatUp || array[i].states.equals("raw") && array[i].type.equals("Grain") ||
                    array[i].type.equals("DairyProduct") && array[i].needToBeatUp) {
                array[i].states = "in the bowl";
                this.hasContent = true;
                this.isClean = false;
                System.out.println("The " + array[i].name + " is " + array[i].states + ".");
            }
        }
    }

    public void putTheBowl(Flavoring[] array){
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("in the container") && array[i].isItForBaking) {
                array[i].states = "in the bowl";
                System.out.println("The content of the " + this.name + " are seasoned.");
                break;
            }
        }
    }

}
