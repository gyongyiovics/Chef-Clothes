package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;

public class Sink {

    public void wash(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].needToWash) {
                array[i].needToWash = false;
                System.out.println(array[i].name + " is " + array[i].isNeedToWash() + ".");
            }
        }
    }
}
