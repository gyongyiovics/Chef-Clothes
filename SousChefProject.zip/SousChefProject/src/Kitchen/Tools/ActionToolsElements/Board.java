package Kitchen.Tools.ActionToolsElements;

import Kitchen.Ingredients.Ingredients;
import Kitchen.Tools.ActionTools;

public class Board extends ActionTools {

    public Board(){
        this.name = "Board";
        this.isClean = true;
        this.hasContent = false;
    }

    public void putTheBoard(Ingredients[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("raw") && array[i].needToCut && !array[i].needToPeel || array[i].states.equals("raw") && array[i].needToCoatWithBreadcrumbs && !array[i].needToPeel) {
                array[i].states = "on the board";
                this.isClean = false;
                System.out.println("The " + array[i].name + " is " + array[i].states + ".");
            }
        }
    }
}