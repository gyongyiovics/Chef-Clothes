package Kitchen.Staff;

import Kitchen.Tools.ActionTools;
import Kitchen.Tools.ActionToolsElements.*;
import RecipeBook.Recipe;

public class SousChef extends PersonnelRecords{

    public SousChef(String name, int age, String position) {
        super(name, age, position);
    }

    public void makeMyFood(Recipe recipe){

        MyHands myHands = new MyHands();

        Pot pot = new Pot();
        pot.putThePot(recipe.boxOfFoodstuff);
        pot.putThePot(recipe.flavoringMixture);

        Pan pan = new Pan();
        pan.putThePan(recipe.boxOfFoodstuff);
        pan.putThePan(recipe.flavoringMixture);

        BakingTin bakingTin = new BakingTin();
        bakingTin.putTheBakingTin(recipe.boxOfFoodstuff);

        WoodenSpoon woodenSpoon = new WoodenSpoon();
        woodenSpoon.mix(pot);
        woodenSpoon.mix(pan);

        Stove stove = new Stove();
        stove.bake(recipe.boxOfFoodstuff);
        stove.cook(recipe.boxOfFoodstuff);
        stove.fry(recipe.boxOfFoodstuff);

        ActionTools[] loadTheDishWasher = {bakingTin, pot, pan, woodenSpoon};
        DishWasher dishWasher = new DishWasher();
        dishWasher.wash(loadTheDishWasher);
        myHands.clean(stove);
        myHands.wash();
    }

}
