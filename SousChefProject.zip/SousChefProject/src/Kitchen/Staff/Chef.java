package Kitchen.Staff;

import Kitchen.Meal;
import RecipeBook.Recipe;

public class Chef extends PersonnelRecords{
    public Chef(String name, int age, String position) {
        super(name, age, position);
    }

    public void checkTheFood(Recipe recipe, Meal meal){
        int checker = 0;
        for (int i = 0; i < recipe.boxOfFoodstuff.length; i++) {
            if(recipe.boxOfFoodstuff[i].getStates().equals("cooked") || recipe.boxOfFoodstuff[i].getStates().equals("fried") || recipe.boxOfFoodstuff[i].getStates().equals("baked") || recipe.boxOfFoodstuff[i].getStates().equals("boiled")){
                checker ++;
            }
        }
        if(checker == recipe.boxOfFoodstuff.length){
            System.out.println("The " + recipe.name + " is ready. Enjoy your food!");

            meal.setName(recipe.name);

            int hotness = recipe.flavoringMixture[0].getHotness();
            for (int i = 0; i < recipe.flavoringMixture.length; i++) {
                if(hotness < recipe.flavoringMixture[i].getHotness()){
                    hotness = recipe.flavoringMixture[i].getHotness();
                }
                meal.setHotness(hotness);
            }

            for (int i = 0; i < recipe.flavoringMixture.length; i++) {
                if(recipe.flavoringMixture[i].getName().equals("Salt")){
                    meal.setSalty(true);
                }else{
                    meal.setSalty(false);
                }
            }

            for (int i = 0; i < recipe.boxOfFoodstuff.length; i++){
                if(recipe.boxOfFoodstuff[i].getType().equals("Meat")){
                    meal.setVegetarianSafe(false);
                }else{
                    meal.setVegetarianSafe(true);
                }
            }

        }
    }

    public void serveTheFood(Recipe recipe, Meal meal){
        KitchenBoy Linguini = new KitchenBoy("Alfredo Linguini", 20, "Kitchen Boy");
        Linguini.prepare(recipe);
        SousChef Colette = new SousChef("Colette", 23, "SousChef");
        Colette.makeMyFood(recipe);
        checkTheFood(recipe, meal);
    }
}
