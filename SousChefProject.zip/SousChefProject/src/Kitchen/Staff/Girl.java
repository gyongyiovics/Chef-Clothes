package Kitchen.Staff;

import Kitchen.Meal;
import Kitchen.Tools.ActionTools;
import Kitchen.Tools.ActionToolsElements.*;
import RecipeBook.Recipe;

public class Girl extends PersonnelRecords{
    public Girl(String name, int age, String position) {
        super(name, age, position);
    }

    public void makeADish(Recipe recipe, Meal meal){
        MyHands myHands = new MyHands();

        Bowl bowl = new Bowl();
        bowl.putTheBowl(recipe.boxOfFoodstuff);
        bowl.putTheBowl(recipe.flavoringMixture);

        Pan pan = new Pan();
        pan.putThePan(recipe.boxOfFoodstuff);
        pan.putThePan(recipe.flavoringMixture);
        System.out.println(recipe.boxOfFoodstuff[0].getStates());
        System.out.println("*********************");

        WoodenSpoon woodenSpoon = new WoodenSpoon();
        woodenSpoon.mix(bowl);

        Stove stove = new Stove();
        stove.fry(recipe.boxOfFoodstuff);
        System.out.println(recipe.boxOfFoodstuff[0].getStates());
        System.out.println("*********************");
        meal.setVegetarianSafe(true);

        ActionTools[] loadTheDishWasher = {bowl, pan, woodenSpoon};
        DishWasher dishWasher = new DishWasher();
        dishWasher.wash(loadTheDishWasher);
        myHands.clean(stove);
        myHands.wash();
    }
}
