package Kitchen.Staff;

import Kitchen.Tools.ActionTools;
import Kitchen.Tools.ActionToolsElements.*;
import RecipeBook.Recipe;

public class KitchenBoy extends PersonnelRecords{

    public KitchenBoy(String name, int age, String position) {
        super(name, age, position);
    }

    public void prepare(Recipe recipe){
        MyHands myHands = new MyHands();

        myHands.wash();
        myHands.crack(recipe.boxOfFoodstuff);

        Bowl bowl = new Bowl();
        bowl.putTheBowl(recipe.boxOfFoodstuff);
        bowl.putTheBowl(recipe.flavoringMixture);

        Fork fork = new Fork();
        fork.beatUp(recipe.boxOfFoodstuff);

        WoodenSpoon woodenSpoon = new WoodenSpoon();
        woodenSpoon.mix(bowl);

        Peeler peeler = new Peeler();
        peeler.peel(recipe.boxOfFoodstuff);

        Sink sink = new Sink();
        sink.wash(recipe.boxOfFoodstuff);

        Board board = new Board();
        board.putTheBoard(recipe.boxOfFoodstuff);

        myHands.coatWithBreadcrumbs(recipe.boxOfFoodstuff);

        Knife knife = new Knife();
        knife.cut(recipe.boxOfFoodstuff);

        Grater grater = new Grater();
        grater.grate(recipe.boxOfFoodstuff);

        ActionTools[] loadTheDishWasher = {bowl, fork, woodenSpoon, peeler, board, knife, grater};
        DishWasher dishWasher = new DishWasher();
        dishWasher.wash(loadTheDishWasher);
        myHands.wash();
    }

}
