package Kitchen;

public class Meal {
    private String name;
    private int hotness;
    private boolean isSalty;
    private boolean isVegetarianSafe;

    public Meal(){}

    public void MealInfo(){
        System.out.println();
        System.out.println(name + ": ");
        System.out.println("----------");
        System.out.println(getHotness());
        System.out.println(isSalty());
        System.out.println(isVegetarianSafe());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHotness() {
        switch (hotness){
            case 0:
                return "This isn't hot.";
            case 1:
                return "This is a little bit hot.";
            case 2:
                return "This is the perfect hotness.";
            case 3:
                return "Ouch! It burns my mouth to ashes.";
            default:
                return "I can't figure out whether the food is hot or not.";
        }
    }

    public void setHotness(int hotness) {
        this.hotness = hotness;
    }

    public String isSalty() {
        return this.isSalty ? "This is a salty food." : "This is a sweet food.";
    }

    public void setSalty(boolean salty) {
        isSalty = salty;
    }

    public String isVegetarianSafe() {
        return this.isVegetarianSafe? "This dish is vegetarian safe." : "This dish contains meat.";
    }

    public void setVegetarianSafe(boolean vegetarianSafe) {
        isVegetarianSafe = vegetarianSafe;
    }
}
