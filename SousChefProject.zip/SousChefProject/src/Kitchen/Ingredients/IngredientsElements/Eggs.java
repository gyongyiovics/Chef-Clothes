package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class Eggs extends Ingredients {
    public Eggs(int quantity) {
        this.type = "Egg";
        this.states = "unbroken";
        this.name = "egg";
        this.needToGrate = false;
        this.isLiquid = false;                 // nyilván folyékony a tojás belseje, de a program működése érdekében sziládraként kell kezelni
        this.needToSqueeze = false;
        this.needToWash = false;
        this.needToCut = false;
        this.needToPeel = false;
        this.needToFry = false;
        this.needToBake = false;
        this.needToCook = false;
        this.needToHeat = false;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = true;
        this.quantity = quantity;
        this.possibleActions = new String[]{"cut", "peel", "bake", "cook",  "beatUp" };
    }

    public String getEggType() {
        return "Made from " + this.type + " eggs.";
    }

}
