package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class PotatoForFrying extends Ingredients {

    public PotatoForFrying(int quantity) {
        this.type = "Vegetable";
        this.states = "raw";
        this.name = "Potato";
        this.needToGrate = false;
        this.isLiquid = false;
        this.needToSqueeze = false;
        this.needToWash = true;
        this.needToCut = true;
        this.needToPeel = true;
        this.needToFry = true;
        this.needToBake = false;
        this.needToCook = false;
        this.needToHeat = false;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = false;
        this.quantity = quantity;
        this.possibleActions = new String[]{"wash", "cut", "peel", "fry", "bake", "cook",  "toast", "coatWithBreadcrumbs"};
    }
}