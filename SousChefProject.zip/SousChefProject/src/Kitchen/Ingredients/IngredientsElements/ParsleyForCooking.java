package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class ParsleyForCooking extends Ingredients {

    public ParsleyForCooking(int quantity) {
        this.type = "Vegetable";
        this.states = "raw";
        this.name = "Parsley";
        this.needToGrate = false;
        this.isLiquid = false;
        this.needToSqueeze = false;
        this.needToWash = true;
        this.needToCut = true;
        this.needToPeel = false;
        this.needToFry = false;
        this.needToBake = false;
        this.needToCook = true;
        this.needToHeat = false;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = false;
        this.quantity = quantity;
        this.possibleActions = new String[]{"cut", "cook", "toast", "wash"};
    }

}
