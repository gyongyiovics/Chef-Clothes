package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class OnionForCooking extends Ingredients {

    public OnionForCooking(int quantity) {
        this.type = "Vegetable";
        this.states = "raw";
        this.name = "Red Onion";
        this.needToGrate = false;
        this.isLiquid = false;
        this.needToSqueeze = false;
        this.needToWash = false;
        this.needToCut = true;
        this.needToPeel = true;
        this.needToFry = false;
        this.needToBake = false;
        this.needToCook = true;
        this.needToHeat = false;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = false;
        this.quantity = quantity;
        this.possibleActions = new String[]{"wash", "cut", "peel", "fry", "bake", "cook",  "toast", "coatWithBreadcrumbs"};
    }

}
