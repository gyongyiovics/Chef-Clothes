package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class FlourForBaking extends Ingredients {
    public FlourForBaking(double quantity) {
        this.type = "Flour";
        this.states = "raw";
        this.name = "Flour";
        this.needToGrate = false;
        this.isLiquid = false;
        this.needToSqueeze = false;
        this.needToWash = false;
        this.needToCut = false;
        this.needToPeel = false;
        this.needToFry = true;
        this.needToBake = false;
        this.needToCook = false;
        this.needToHeat = false;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = false;
        this.quantity = quantity;
        this.possibleActions = new String[]{"wash", "cut", "peel", "fry", "bake", "cook",  "toast", "coatWithBreadcrumbs"};
    }
}
