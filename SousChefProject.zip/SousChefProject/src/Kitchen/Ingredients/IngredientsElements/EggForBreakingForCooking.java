package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class EggForBreakingForCooking extends Ingredients {

    public EggForBreakingForCooking(int quantity) {
        this.type = "Egg";
        this.states = "unbroken";
        this.name = "Chicken Egg";
        this.needToGrate = false;
        this.isLiquid = false;                 // nyilván folyékony a tojás belseje, de a program működése érdekében sziládraként kell kezelni
        this.needToSqueeze = false;
        this.needToWash = false;
        this.needToCut = false;
        this.needToPeel = false;
        this.needToFry = false;
        this.needToBake = false;
        this.needToCook = true;
        this.needToHeat = false;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = true;
        this.quantity = quantity;
        this.possibleActions = new String[]{"cut", "peel", "bake", "cook",  "beatUp" };
    }

    public String getEggType() {
        return "Made from " + this.type + " eggs.";
    }

}
