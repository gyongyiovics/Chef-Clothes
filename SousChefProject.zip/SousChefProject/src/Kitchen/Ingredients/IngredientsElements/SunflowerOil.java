package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class SunflowerOil extends Ingredients {

    public SunflowerOil(int quantity) {
        this.type = "Fat";
        this.states = "raw";
        this.name = "SunflowerOil";
        this.needToGrate = false;
        this.isLiquid = true;
        this.needToSqueeze = false;
        this.needToWash = false;
        this.needToCut = false;
        this.needToPeel = false;
        this.needToFry = true;
        this.needToBake = false;
        this.needToCook = false;
        this.needToHeat = true;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = false;
        this.quantity = quantity;
        this.possibleActions = new String[]{"cut", "fry", "bake", "cook",  "toast", "coatWithBreadcrumbs"};
    }
}
