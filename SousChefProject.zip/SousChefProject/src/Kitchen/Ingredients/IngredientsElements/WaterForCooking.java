package Kitchen.Ingredients.IngredientsElements;

import Kitchen.Ingredients.Ingredients;

public class WaterForCooking extends Ingredients {

    public WaterForCooking(int quantity) {
        this.type = "Liquid";
        this.states = "raw";
        this.name = "Water";
        this.needToGrate = false;
        this.isLiquid = true;
        this.needToSqueeze = false;
        this.needToWash = false;
        this.needToCut = false;
        this.needToPeel = false;
        this.needToFry = false;
        this.needToBake = false;
        this.needToCook = true;
        this.needToHeat = true;
        this.needToToast = false;
        this.needToCoatWithBreadcrumbs = false;
        this.needToBeatUp = false;
        this.quantity = quantity;
        this.possibleActions = new String[]{"cook"};
    }

}
