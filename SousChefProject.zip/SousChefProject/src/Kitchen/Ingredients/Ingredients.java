package Kitchen.Ingredients;

public class Ingredients {
    public String type; // a hozzávaló gyüjtőneve pl.: Vegetable, Meat, Fish, Fruit, Pasta, Liquid, Fat, stb....
    public String states;
    public String name;
    public double quantity;
    public boolean needToGrate;
    public boolean isLiquid;
    public boolean needToSqueeze;
    public boolean needToWash;
    public boolean needToCut;
    public boolean needToPeel;
    public boolean needToFry;
    public boolean needToBake;
    public boolean needToCook;
    public boolean needToHeat;
    public boolean needToToast;
    public boolean needToCoatWithBreadcrumbs;
    public boolean needToBeatUp;
    public String[] possibleActions;  // ezt még nem tudom, hogy használni akarom-e bármire, de inkább legyen, mint ne legyen


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String isNeedToWash() {
        return this.needToWash ? "dirty" : "clean";
    }

    public void setNeedToWash(boolean needToWash) {
        this.needToWash = needToWash;
    }

    public String isNeedToCut() {
        return this.needToCut ? "whole" : "in pieces";
    }

    public void setNeedToCut(boolean needToCut) {
        this.needToCut = needToCut;
    }

    public String isNeedToPeel() {
        return this.needToPeel ? "in the shell" : "peeled";
    }

    public void setNeedToPeel(boolean needToPeel) {
        this.needToPeel = needToPeel;
    }

    public String isNeedToFry() {
        return this.needToFry ? "raw" : "fried";
    }

    public void setNeedToFry(boolean needToFry) {
        this.needToFry = needToFry;
    }

    public String isNeedToBake() {
        return this.needToBake ? "raw" : "baked";
    }

    public void setNeedToBake(boolean needToBake) {
        this.needToBake = needToBake;
    }

    public boolean isNeedToCook() {
        return needToCook;
    }

    public void setNeedToCook(boolean needToCook) {
        this.needToCook = needToCook;
    }

    public String isNeedToHeat() {
        return this.needToHeat ? "cold" : "boiled";
    }

    public void setNeedToHeat(boolean needToHeat) {
        this.needToHeat = needToHeat;
    }

    public String isNeedToToast() {
        return this.needToToast ? "raw" : "toasted";
    }

    public void setNeedToToast(boolean needToToast) {
        this.needToToast = needToToast;
    }

    public String isNeedToCoatWithBreadcrumbs() {
        return this.needToCoatWithBreadcrumbs ? "naked" : "coated";
    }

    public void setNeedToCoatWithBreadcrumbs(boolean needToCoatWithBreadcrumbs) {
        this.needToCoatWithBreadcrumbs = needToCoatWithBreadcrumbs;
    }

    public String isNeedToBeatUp() {
        return this.needToBeatUp ? "jellied" : "beaten up";
    }

    public void setNeedToBeatUp(boolean needToBeatUp) {
        this.needToBeatUp = needToBeatUp;
    }

    public String[] getPossibleActions() {
        return possibleActions;
    }

    public void setPossibleActions(String[] possibleActions) {
        this.possibleActions = possibleActions;
    }

    public String isNeedToGrate() {
        return this.needToGrate ? "whole" : "grated";
    }

    public void setNeedToGrate(boolean needToGrate) {
        this.needToGrate = needToGrate;
    }

    public String isLiquid() {
        return this.isLiquid ? "liquid" : "solid";
    }

    public void setLiquid(boolean liquid) {
        isLiquid = liquid;
    }

    public String isNeedToSqueeze() {
        return this.needToSqueeze? "untouched" : "juice";
    }

    public void setNeedToSqueeze(boolean needToSqueeze) {
        this.needToSqueeze = needToSqueeze;
    }
}
