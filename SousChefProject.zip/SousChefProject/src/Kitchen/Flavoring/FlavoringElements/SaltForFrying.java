package Kitchen.Flavoring.FlavoringElements;

import Kitchen.Flavoring.Flavoring;

public class SaltForFrying extends Flavoring {

    public SaltForFrying(int hotness) {
        super();
        this.states = "in the container";
        this.name = "Salt";
        this.quantity = "pinch";
        this.hotness = hotness;
        this.type = "Himalaya";
        this.isItForCooking = false;
        this.isItForBaking = false;
        this.isItForFrying = true;
    }
}
