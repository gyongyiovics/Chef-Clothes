package Kitchen.Flavoring.FlavoringElements;

import Kitchen.Flavoring.Flavoring;

public class HoneyForBaking extends Flavoring {
    public HoneyForBaking(int hotness){
        super();
        this.states = "in the container";
        this.name = "Honey";
        this.quantity = "spoon";
        this.hotness = hotness;
        this.type = "FlowerHoney";
        this.isItForCooking = false;
        this.isItForBaking = true;
        this.isItForFrying = false;
    }
}
