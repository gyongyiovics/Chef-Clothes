package Kitchen.Flavoring.FlavoringElements;

import Kitchen.Flavoring.Flavoring;

public class SugarForBaking extends Flavoring {
    public SugarForBaking(int hotness){
        super();
        this.states = "in the container";
        this.name = "Cane Sugar";
        this.quantity = "spoon";
        this.hotness = hotness;
        this.type = "Made from Cane";
        this.isItForCooking = false;
        this.isItForBaking = true;
        this.isItForFrying = false;
    }
}
