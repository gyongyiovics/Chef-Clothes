package Kitchen.Flavoring.FlavoringElements;

import Kitchen.Flavoring.Flavoring;

public class RedPaprikaPowder extends Flavoring {

    public RedPaprikaPowder(int hotness) {
        super();
        this.states = "in the container";
        this.name = "Red Paprika Powder";
        this.quantity = "spoon";
        this.hotness = hotness;
        this.type = "Hot";
        this.isItForCooking = true;
        this.isItForBaking = false;
        this.isItForFrying = false;
    }

}
