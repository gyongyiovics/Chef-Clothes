package Kitchen.Flavoring.FlavoringElements;

import Kitchen.Flavoring.Flavoring;

public class PepperForCooking extends Flavoring {

    public PepperForCooking(int hotness) {
        super();
        this.states = "in the container";
        this.name = "Pepper";
        this.quantity = "pinch";
        this.hotness = hotness;
        this.type = "Himalaya";
        this.isItForCooking = true;
        this.isItForBaking = false;
        this.isItForFrying = false;

    }
}
