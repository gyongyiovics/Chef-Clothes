package Kitchen.Flavoring.FlavoringElements;

import Kitchen.Flavoring.Flavoring;

public class SaltForCooking extends Flavoring {

    public SaltForCooking(int hotness) {
        super();
        this.states = "in the container";
        this.name = "Salt";
        this.quantity = "pinch";
        this.hotness = hotness;
        this.type = "Himalaya";
        this.isItForCooking = true;
        this.isItForBaking = false;
        this.isItForFrying = false;

    }

}
