package Kitchen.Flavoring;

public class Flavoring {
    public String states;
    protected String name;
    protected String quantity;
    protected int hotness;
    protected String type;
    public boolean isItForCooking;
    public boolean isItForBaking;
    public boolean isItForFrying;

    public Flavoring(String states, String name, String quantity, int hotness, String type, boolean isItForCooking, boolean isItForBaking, boolean isItForFrying) {
        this.states = states;
        this.name = name;
        this.quantity = quantity;
        this.hotness = hotness;
        this.type = type;
        this.isItForCooking = isItForCooking;
        this.isItForBaking = isItForBaking;
        this.isItForFrying = isItForFrying;
    }

    public Flavoring(){}

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return switch (this.quantity) {
            case "pinch" -> "Slightly tasteless.";
            case "spoon" -> "Tasty.";
            case "ladle" -> "Too intense flavors.";
            default -> "Poisonous";
        };
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public int getHotness() {
        return hotness;
    }

    public void setHotness(int hotness) {
        this.hotness = hotness;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isItForCooking() {
        return isItForCooking;
    }

    public void setItForCooking(boolean itForCooking) {
        isItForCooking = itForCooking;
    }

    public boolean isItForBaking() {
        return isItForBaking;
    }

    public void setItForBaking(boolean itForBaking) {
        isItForBaking = itForBaking;
    }

    public boolean isItForFrying() {
        return isItForFrying;
    }

    public void setItForFrying(boolean itForFrying) {
        isItForFrying = itForFrying;
    }
}
