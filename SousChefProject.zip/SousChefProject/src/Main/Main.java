package Main;

import Kitchen.Meal;
import Kitchen.Staff.Chef;
import Kitchen.Staff.Girl;
import Kitchen.Staff.KitchenBoy;
import Kitchen.Staff.SousChef;
import RecipeBook.ChickenSoup;
import RecipeBook.FishAndChips;
import RecipeBook.PanCakes;
import RecipeBook.Ratatouille;

public class Main {
    public static void main(String[] args) {
        Meal meal = new Meal();
        Ratatouille ratatouille = new Ratatouille();
        FishAndChips fishAndChips = new FishAndChips();
        ChickenSoup chickenSoup = new ChickenSoup();
        PanCakes pancakes = new PanCakes();

        Chef Remy = new Chef("Remy", 18, "Chef");
        KitchenBoy Billy = new KitchenBoy("Billy", 17, "kitchen boy");
        SousChef Gary = new SousChef("Gérard", 45, "sousChef");
        Girl Gizi = new Girl("Gizi", 34, "pancake expert");
        //Gizi.makeADish(pancakes, meal);
        //Remy.serveTheFood(ratatouille, meal);
        Remy.serveTheFood(pancakes, meal);
        //Remy.serveTheFood(chickenSoup, meal);
        meal.MealInfo();
    }
}
