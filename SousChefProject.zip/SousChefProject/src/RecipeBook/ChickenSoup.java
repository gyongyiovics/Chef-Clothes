package RecipeBook;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Flavoring.FlavoringElements.PepperForCooking;
import Kitchen.Flavoring.FlavoringElements.SaltForCooking;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Ingredients.IngredientsElements.*;

public class ChickenSoup extends Recipe{

    public ChickenSoup(){
        super();
        this.name = "Chicken Soup";
        this.boxOfFoodstuff = new Ingredients[] {
                new CarrotForCooking(4),
                new CeleryForCooking(1),
                new ChickenBreastFilletForCooking(1),
                new GarlicForCooking(2),
                new ParsleyForCooking(1),
                new RootForCooking(2),
                new VermicelliForCooking(0.25),
                new WaterForCooking(5)
        };

        this.flavoringMixture = new Flavoring[]{
                new PepperForCooking(1),
                new SaltForCooking(0)
        };
    }
}