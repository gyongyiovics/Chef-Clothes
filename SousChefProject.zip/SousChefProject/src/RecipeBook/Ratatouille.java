package RecipeBook;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Flavoring.FlavoringElements.RedPaprikaPowder;
import Kitchen.Flavoring.FlavoringElements.SaltForCooking;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Ingredients.IngredientsElements.*;

public class Ratatouille extends Recipe{

    public Ratatouille(){
        super();
        this.name = "Ratatouille";
        this.boxOfFoodstuff = new Ingredients[]{
                new EggForBreakingForCooking(3),
                new OnionForCooking(1),
                new PaprikaForCooking(4),
                new SausageForCooking(1),
                new TomatoForCooking(4)
        };

        this.flavoringMixture = new Flavoring[]{
                new RedPaprikaPowder(3),
                new SaltForCooking(0)
        };
    }

}