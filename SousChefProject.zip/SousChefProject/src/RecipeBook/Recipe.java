package RecipeBook;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Ingredients.Ingredients;

public class Recipe {
    public String name;
    public Flavoring[] flavoringMixture;
    public Ingredients[] boxOfFoodstuff;

    public Recipe(String name, Flavoring[] flavoringMixture, Ingredients[] boxOfFoodstuff) {
        this.name = name;
        this.flavoringMixture = flavoringMixture;
        this.boxOfFoodstuff = boxOfFoodstuff;
    }

    public Recipe(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Flavoring[] getFlavoringMixture() {
        return flavoringMixture;
    }

    public void setFlavoringMixture(Flavoring[] flavoringMixture) {
        this.flavoringMixture = flavoringMixture;
    }

    public Ingredients[] getBoxOfFoodstuff() {
        return boxOfFoodstuff;
    }

    public void setBoxOfFoodstuff(Ingredients[] boxOfFoodstuff) {
        this.boxOfFoodstuff = boxOfFoodstuff;
    }
}
