package RecipeBook;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Flavoring.FlavoringElements.SaltForFrying;
import Kitchen.Flavoring.FlavoringElements.SugarForBaking;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Ingredients.IngredientsElements.*;

public class PanCakes extends Recipe{

    public PanCakes(){
        super();
        this.name = "Pancakes";
        this.boxOfFoodstuff = new Ingredients[]{
                new SunflowerOil(1),
                new Eggs(1),
                new MineralWater(1),
                new FlourForBaking(0.5)
        };

        this.flavoringMixture = new Flavoring[]{
                new SaltForFrying(0),
                new SugarForBaking(0)
        };
    }
}
