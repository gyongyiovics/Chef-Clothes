package RecipeBook;

import Kitchen.Flavoring.Flavoring;
import Kitchen.Flavoring.FlavoringElements.SaltForFrying;
import Kitchen.Ingredients.Ingredients;
import Kitchen.Ingredients.IngredientsElements.*;

public class FishAndChips extends Recipe{

    public FishAndChips(){
        super();
        this.name = "FishAndChips";
        this.boxOfFoodstuff = new Ingredients[]{
                new FishForFrying(4),
                new PotatoForFrying(8),
                new SunflowerOil(1)
        };

        this.flavoringMixture = new Flavoring[]{
                new SaltForFrying(0)
        };
    }
}
