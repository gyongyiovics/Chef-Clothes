package ingredients;

public class Vegetables extends Ingredients {
    public boolean isWashed;
    public boolean isPeeled;
    public boolean isCut;

    public Vegetables(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
        this.isWashed = false;
        this.isPeeled = false;
        this.isCut = false;
    }

    public String isWashed() {
        return this.isWashed ? "washed" : "dirty";
    }

    public void setWashed(boolean washed) {
        isWashed = washed;
    }

    public String isPeeled() {
        return this.isPeeled ? "peeled" : "inTheShell";
    }

    public void setPeeled(boolean peeled) {
        isPeeled = peeled;
    }

    public String isCut() {
        return this.isCut ? "cut" : "uncut";
    }

    public void setCut(boolean cut) {
        isCut = cut;
    }

}
