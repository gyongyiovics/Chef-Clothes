package ingredients.spices;


public class Sugar extends Spices {
    public Sugar(String states, String name, String quantity) {
        super(states, name, quantity);
    }

    @Override
    public String getState() {
        return super.getState();
    }

    @Override
    public void setState(String state) {
        super.setState(state);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public String getQuantity() {
        return super.getQuantity();
    }

    @Override
    public void setQuantity(String quantity) {
        super.setQuantity(quantity);
    }
}
