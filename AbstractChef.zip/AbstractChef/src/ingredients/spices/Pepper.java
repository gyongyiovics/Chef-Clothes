package ingredients.spices;

public class Pepper extends Spices {
    private int intensity;

    public Pepper(String states, String name, String quantity, int intensity) {
        super(states, name, quantity);
        this.intensity = intensity;
    }

    public String getIntensity() {
        return switch (intensity) {
            case 0 -> "This isn't spicy.";
            case 1 -> "It's a little bit hot.";
            case 2 -> "This is what I want.";
            case 3 -> "Ouch, it burns my mouth to ashes!";
            default -> "I can't figure out if it is hot or not.";
        };
    }

    public void setIntensity(int intensity) {
        this.intensity = intensity;
    }
}
