package ingredients;

public class Flour extends Ingredients{
    public Flour(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    @Override
    public int getQuantity() {
        return super.getQuantity();
    }

    @Override
    public void setQuantity(int quantity) {
        super.setQuantity(quantity);
    }
}
