package ingredients;

public class Eggs extends Ingredients {
    private String typeOf;

    public Eggs(String typeOf, int quantity) {
        this.typeOf = typeOf;
        this.name = "egg";
        this.states = "unbroken";
        this.quantity = quantity;
    }

    public String getTypeOf() {
        return typeOf.equals("chicken")? "chicken eggs" : "some unknown eggs";
    }

    public void setTypeOf(String typeOf) {
        this.typeOf = typeOf;
    }
}
