package ingredients;

public class Magic extends Ingredients {
    private boolean doesWork;
    private String type;

    public Magic(String states, String name, int quantity, boolean doesWork, String type) {
        this.doesWork = doesWork;
        this.type = type;
    }

    public boolean isDoesWork() {
        return doesWork;
    }

    public void setDoesWork(boolean doesWork) {
        this.doesWork = doesWork;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
