package ingredients;

public class MineralWater extends Ingredients{
    public MineralWater(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
        //TODO: metric --> liters, deciliters, etc
    }

}
