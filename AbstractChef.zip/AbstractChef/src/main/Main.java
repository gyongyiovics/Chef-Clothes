package main;

import recipe.PanCake;

public class Main {
    public static void main(String[] args) {
        /*LecsoRecipe lecso = new LecsoRecipe(){};
        lecso.makeRecipe();
         */

        PanCake palacsinta = new PanCake();
        palacsinta.makePanCakes();
    }
}
