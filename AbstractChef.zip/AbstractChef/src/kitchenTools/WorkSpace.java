package kitchenTools;

import ingredients.Ingredients;

public class WorkSpace extends KitchenTools {
    private double size;
    public boolean inUse;

    public WorkSpace(double size, String name, boolean isWire) {
        this.size = size;
        this.inUse = false;
        this.name = name;
        this.isWire = isWire;
    }

    public String isInUse() {
        return this.inUse ? "used": "not in use";
    }
    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }

    //TODO: activities related to workspaces? - put on, put in, mix, cook
    public void workSpaceActivities(Ingredients ingredients, WorkSpace workSpace){
        if (workSpace.getName().equals("board")){
            putOnto(ingredients, workSpace);
        }
        putInto(ingredients, workSpace);
    }

    //set the state to "on the board"
    private void putOnto (Ingredients ing, WorkSpace workSpace){
        ing.setStates("on the board");
        workSpace.setInUse(true);
        System.out.println("Now all the " + ing.getName() + " is/are on the " + workSpace.getName() + ", so I can cut it/them.");
    }

    private void putInto(Ingredients ing, WorkSpace workSpace){
        ing.setStates("in the " + workSpace.getName());
        workSpace.setInUse(true);
        System.out.println("Now all the " + ing.getName() + " is/are on the " + workSpace.getName() + ".");
    }

    public void mix(WorkSpace workSpace, Ingredients ingredient){
        if(workSpace.inUse){
            ingredient.setStates("mixed");
            System.out.println("The contents of the " + workSpace.getName() + " is " + ingredient.getStates() + ".");
        }
    }

    public void cook(WorkSpace workSpace, Ingredients ingredient){
        if(workSpace.inUse){
            ingredient.setStates("cooked");
            System.out.println("The contents of the " + workSpace.getName() + " is " + ingredient.getStates() + ".");
        }
    }

}
