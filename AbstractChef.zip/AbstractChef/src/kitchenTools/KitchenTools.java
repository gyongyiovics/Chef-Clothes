package kitchenTools;

public class KitchenTools {
    public String name;
    protected boolean isWire;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isWire() {
        return isWire;
    }

    public void setWire(boolean wire) {
        this.isWire = wire;
    }

}
