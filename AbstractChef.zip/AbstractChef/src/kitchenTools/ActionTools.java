package kitchenTools;

import ingredients.Vegetables;

public class ActionTools extends KitchenTools {
    public boolean isSharp;
    public boolean isClean;

    public ActionTools(boolean isSharp, String name, boolean isWire, boolean isClean) {
        this.name = name;
        this.isWire = isWire;
        this.isSharp = isSharp;
        this.isClean = isClean;
    }
    public String isClean() {
        if (isClean){
            return "clean";
        } else {
            return "dirty";
        }
    }

    //TODO: activities related to actiontools? - clean, cut

    public void peelAndcut(ActionTools actionTools, Vegetables vegetables){
        if(!vegetables.isPeeled){
           actionTools.peelThemAll(vegetables);
        }
        actionTools.cut(vegetables);
    }

    private void peelThemAll(Vegetables vegetables){
        vegetables.isPeeled = true;
    }

    private void cut(Vegetables vegetables){
        vegetables.isCut = true;
    }
}
