package recipe;

import ingredients.Eggs;
import ingredients.Vegetables;
import kitchenTools.ActionTools;
import kitchenTools.WorkSpace;
import ingredients.spices.Pepper;
import ingredients.spices.Salt;
import ingredients.spices.Spices;

import activities.Activities;

public class LecsoRecipe {
    public static String info(){
        return "This is a lecso recipe. Let's cook it!";
    }

    //TODO: recipe processor
    public static void makeRecipe() {
        System.out.println(info());
        System.out.println("****************************");
        Eggs eggs = new Eggs("chicken", 2);

        Vegetables[] bowlOfVeggies = {
                new Vegetables("paprika", 5),
                new Vegetables( "fürtös", 2),
                new Vegetables("redonion", 1),
                new Vegetables("hegyeserős", 1)};
        //TODO: Ingredients[] array for a check?

        //TODO: Spices[] array and a duplicate
        Spices[] cupOfSpice = {
                new Salt("inTheContainer", "salt", "spoon", "deMaar"),
                new Pepper("inTheContainer", "bors", "pinch", 3)};
        Salt salty = new Salt("inTheContainer", "salt", "spoon", "deMaar");
        Pepper peppery = new Pepper("inTheContainer", "bors", "pinch", 3);


        ActionTools woodenSpoon = new ActionTools(false, "faKanál", false, true);
        ActionTools knife = new ActionTools(true, "kés", false, true);
        ActionTools myHands = new ActionTools(false, "kezeim", false, false);
        ActionTools stove = new ActionTools(false, "túzhely", true, true);
        ActionTools fork = new ActionTools(false, "villa", false, true);

        ActionTools[] allTools = {
                new ActionTools(false, "faKanál", false, true),

                woodenSpoon, knife, myHands, fork, stove, fork};

        WorkSpace bowl = new WorkSpace(1.0, "bowl", false);
        WorkSpace cuttingBoard = new WorkSpace(1.4, "board", false);
        WorkSpace pan = new WorkSpace(2.1, "pan", false);

        WorkSpace[] workSpaces = {bowl, cuttingBoard, pan};

        Activities activities = new Activities();

        //check if tools, hands, vegetables are clean
        activities.wash(myHands);

        activities.wash(bowlOfVeggies);
        activities.peel(bowlOfVeggies);
        activities.cutUp(bowlOfVeggies);

        //use the tools accordingly if they are needed
        activities.crack(eggs);
        System.out.println(eggs.getStates());
        activities.beatenUp(eggs);
        activities.putTheBowl(eggs, bowl);
        System.out.println(eggs.getStates());
        activities.putThePan(cupOfSpice);

        activities.putThePan(eggs);
        System.out.println(eggs.getStates());
        System.out.println(eggs.getStates());
        activities.mixed(pan);
        activities.putOnto(bowlOfVeggies, cuttingBoard);
        //System.out.println(bowlOfVeggies[0].getStates());
        activities.putThePan(bowlOfVeggies, pan);
        activities.putThePan(eggs);
        //activities.cook(bowlOfVeggies);
        //activities.cook(eggs);
        activities.cookContent(pan);

        foodInfo("lecsóóóó", peppery, eggs, salty);
    }

    public static void foodInfo(String name, Pepper pepper, Eggs eggs, Salt salt){
        System.out.println();
        System.out.println(name + ": ");
        System.out.println("----------");
        System.out.println("The intensity of the meal is: " + pepper.getIntensity());
        System.out.println("The egg I used for it: " + eggs.getTypeOf());
        System.out.println("The level of saltiness is: " + salt.getQuantity());
    }
}
