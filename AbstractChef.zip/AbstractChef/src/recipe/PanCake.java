package recipe;

import activities.Activities;
import ingredients.Eggs;
import ingredients.Flour;
import ingredients.Ingredients;
import ingredients.MineralWater;
import ingredients.spices.Salt;
import ingredients.spices.Spices;
import ingredients.spices.Sugar;
import kitchenTools.WorkSpace;

public class PanCake {
    public static String info(){
        return "This is a pancake recipe. Let's make some!";
    }

    public static void makePanCakes(){
        System.out.println(info());

        //ingredients
        Ingredients water = new MineralWater("soda", 1);
        Ingredients flour = new Flour("flour", 1);
        Ingredients egg = new Eggs("chicken", 1);
        Spices salt = new Salt("inContainer", "salt", "pinch", "tengeri");
        Spices sugar = new Sugar("inContainer","sugar", "spoonful");

        WorkSpace bowl = new WorkSpace(1.3, "bowl", false);
        WorkSpace pan  = new WorkSpace(1.4, "pan", true);

        Ingredients[] rawMaterial = {water, flour, egg};
        Spices[] spices = {salt, sugar};

        Activities activities = new Activities();

        //TODO: add more ingredients
        activities.putTheBowlAny(water, bowl);
        activities.putTheBowlAny(flour, bowl);
        activities.putTheBowlAny(egg, bowl);
        activities.putTheBowlSpices(salt, bowl);
        activities.putTheBowlSpices(sugar, bowl);

        activities.mixed(bowl);


    }
}
