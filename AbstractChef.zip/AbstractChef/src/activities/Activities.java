package activities;

import ingredients.*;
import ingredients.spices.Spices;
import kitchenTools.*;


public class Activities {
    //ActionTools
    //TODO -> needs to be washed
    public void wash(ActionTools actionTools){
        if(!actionTools.isClean){
            actionTools.isClean = true;
            System.out.println("The " + actionTools.getName() + " is " + actionTools.isClean() + ".");
        }
    }

    public void wash(Vegetables[] array){
        for (Vegetables vegetables : array) {
            if (!vegetables.isWashed) {
                vegetables.isWashed = true;
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is washed.");
    }

    //TODO -> one veggie?
    public void peel(Vegetables[] array){
        for (Vegetables vegetables : array) {
            if (!vegetables.isPeeled) {
                vegetables.isPeeled = true;
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is peeled.");
    }

    public void cutUp(Vegetables[] array){
        for (Vegetables vegetables : array) {
            if (!vegetables.isCut) {
                vegetables.isCut = true;
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is cut.");
    }

    public void crack(Ingredients ingredient){
        String states = ingredient.getStates();
        if(states.equals("unbroken")){
            ingredient.setStates("cracked");
            System.out.println("The state of " + ingredient.getName() + " is now: " + ingredient.getStates() + ".");
        }
    }

    public void beatenUp(Ingredients ingredient){
        String states = ingredient.getStates();
        if(states.equals("cracked")){
            ingredient.setStates("beaten up");
            System.out.println("The state of " + ingredient.getName() + " is now: " + ingredient.getStates() + ".");
        }
    }

    public void mixed(WorkSpace workSpace){
        if(workSpace.inUse){
            System.out.println("The contents of the " + workSpace.getName() + " is mixed.");
        }
    }

    //TODO same type for cook?
    public void cookContent(WorkSpace workSpace){
        if(workSpace.inUse){
            System.out.println("The content of the " + workSpace.getName() + " is cooked.");
        }
    }

    public void cook(Vegetables[] array){
        for (Vegetables vegetables : array) {
            String states = vegetables.getStates();
            if (states.equals("in the pan")) {
                states = "cooked";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is cooked.");
    }

    public void cook(Ingredients ingredients){
        String states = ingredients.getStates();
        if(states.equals("in the pan")){
            states = "cooked";
            System.out.println("The state of " + ingredients.name + " is now " + states + ".");
        }
    }

    //TODO: one method with Ingredients?
    public static void allInOneLine(Vegetables[] veggies){
        for (Vegetables veggy : veggies) {
            if (veggy == veggies[veggies.length - 1]) {
                System.out.print(veggy.getName());
            } else {
                System.out.print(veggy.getName() + ", ");
            }
        }
    }

    public static void allInOneLine(Spices[] spices){
        for (Spices spice : spices) {
            if (spice == spices[spices.length - 1]) {
                System.out.print(spice.getName());
            } else {
                System.out.print(spice.getName() + ", ");
            }
        }
    }
    
    //WorkSpaces
    //TODO: workspace in one method, onto or into
    public void putOnto(Vegetables[] array, WorkSpace workSpace){
        String where = "";
        for (Vegetables vegetables : array) {
            String states = vegetables.getStates();
            if (states.equals("raw")){ states = " on the " + workSpace.getName(); }

        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: on the " + workSpace.getName());

        workSpace.inUse = true;
        System.out.println("The state of " + workSpace.getName() + " is now " + workSpace.isInUse() + ".");
    }

    //put --> in the bowl
    public void putTheBowl(Ingredients ingredients, WorkSpace bowl){
        String states = ingredients.getStates();
        if(states.equals("beaten up")){ //TODO: ingredients.getStates()??
            ingredients.setStates("in the bowl");
            System.out.println("The state of " + ingredients.name + " is now: " + states + ".");
            bowl.setInUse(true);
        }
    }

    public void putTheBowlAny(Ingredients ingredients, WorkSpace bowl){
        String states = ingredients.getStates();
        if(states.equals(states)){ //TODO: ingredients.getStates()??
            ingredients.setStates("in the bowl");
            System.out.println("The state of " + ingredients.getName() + " is now: " + ingredients.getStates() + ".");
            bowl.setInUse(true);
        }
    }

    //removed condition about the state as it is always true!
    public void putTheBowlSpices(Spices spices, WorkSpace bowl){
        spices.setState("in the bowl");
        System.out.println("The state of " + spices.getName() + " is now: " + spices.getState() + ".");
        bowl.setInUse(true);
    }

    //put --> in the pan
    //TODO: workspace in one method
    public void putThePan(Vegetables[] array, WorkSpace pan){
        for (Vegetables vegetables : array) {
            String states = vegetables.getStates();
            if (states.equals("on the board")) {
                states = "in the pan";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pan.");

        pan.inUse = true;
        System.out.println("The state of " + pan.getName() + " is now " + pan.isInUse() + ".");
    }

    public void putThePan(Spices[] array){
        for (Spices spices : array) {
            if (spices.states.equals("inTheContainer")) {
                spices.states = "in the pan";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pan.");
    }

    public void putThePan(Ingredients ingredients){
        String states = ingredients.getStates();
        if(states.equals("in the bowl")){//in the bowl
            ingredients.setStates("in the pan");
            System.out.println("The state of " + ingredients.name + " is now: " + states + ".");
        }
    }

    //put --> in the pot
    //TODO: workspace in one method
    public void putThePot(Vegetables[] array, WorkSpace pot){
        for (Vegetables vegetables : array) {
            String states = vegetables.getStates();
            if (states.equals("on the board")) {
                states = "in the pot";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pot.");

        pot.inUse = true;
        System.out.println("The state of " + pot.getName() + " is now " + pot.isInUse() + ".");
    }

    public void putThePot(Spices[] array){
        for (Spices spices : array) {
            if (spices.states.equals("inTheContainer")) {
                spices.states = "in the pot";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pot.");
    }

    public void putThePot(Ingredients ingredients){
        String states = ingredients.getStates();
        if(states.equals("beaten up")){//in the bowl
            states = "in the pot";
            System.out.println("The state of " + ingredients.name + " is now: " + states + ".");
        }
    }

}
