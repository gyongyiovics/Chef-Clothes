package cooking.main;

import cooking.ingredientsElements.Eggs;
import cooking.ingredientsElements.Ingredients;
import cooking.ingredientsElements.Vegetables;
import cooking.spicesElements.Pepper;
import cooking.spicesElements.Salt;
import cooking.spicesElements.Spices;
import cooking.toolsElements.ActionTools;
import cooking.toolsElements.WorkSpace;

public class Recipe {

    public void info(){
        System.out.println("This is a lecso recipe. Let's cook it");
    }
    public void makeRecipe() {
        Meal ratatouille = new Meal();

        Eggs eggs = new Eggs("chicken", "egg", 2);

        Vegetables[] bowlOfVeggies = {
                new Vegetables("paprika", 5),
                new Vegetables( "fürtös", 2),
                new Vegetables("redonion", 1),
                new Vegetables("hegyeserős", 1)};
        //Ingredients[] array for a check?

        //Spices[] array and a duplicate
        Spices[] cupOfSpice = {
                new Salt("inTheContainer", "salt", "spoon", "deMaar"),
                new Pepper("inTheContainer", "bors", "pinch", 3)};
        Salt salty = new Salt("inTheContainer", "salt", "spoon", "deMaar");
        Pepper peppery = new Pepper("inTheContainer", "bors", "pinch", 3);


        ActionTools woodenSpoon = new ActionTools(false, "faKanál", false, true);
        ActionTools knife = new ActionTools(true, "kés", false, true);
        ActionTools myHands = new ActionTools(false, "kezeim", false, false);
        ActionTools stove = new ActionTools(false, "túzhely", true, true);
        ActionTools fork = new ActionTools(false, "villa", false, true);

        ActionTools[] allTools = {
                new ActionTools(false, "faKanál", false, true),

                woodenSpoon, knife, myHands, fork, stove, fork};

        WorkSpace bowl = new WorkSpace(1.0, "bowl", false);
        WorkSpace cuttingBoard = new WorkSpace(1.4, "board", false);
        WorkSpace pan = new WorkSpace(2.1, "pan", false);

        WorkSpace[] workSpaces = {bowl, cuttingBoard, pan};

        //check if tools, hands, vegetables are clean

        myHands.wash();

        myHands.wash(bowlOfVeggies);
        myHands.peel(bowlOfVeggies);
        knife.cutUp(bowlOfVeggies);

        //use the tools accordingly if they are needed
        myHands.crack(eggs);
        fork.beatenUp(eggs);
        bowl.putTheBowl(eggs);

        pan.putThePan(cupOfSpice);

        pan.putThePan(bowlOfVeggies);

        pan.putThePan(eggs);

        woodenSpoon.mixed(pan);

        cuttingBoard.putTheBoard(bowlOfVeggies);
        pan.putThePan(bowlOfVeggies);

        stove.cook(bowlOfVeggies);
        stove.cook(eggs);

        serveTheFood(bowlOfVeggies, peppery,salty, eggs, ratatouille);
        ratatouille.mealInfo();
    }
    public static void serveTheFood (Vegetables[] vegetables, Pepper pepper, Salt salt, Eggs eggs, Meal meal){
        for (int i = 0; i < vegetables.length; i++) {
            if(vegetables[i].states.equals("cooked")){
                meal.setName("Lecsó");
                meal.setIntensity(pepper.getIntensity());
                meal.setEggType(eggs.getTypeOf());
                meal.setIsSalty(salt.getQuantity());
                System.out.println(meal.getName() + " is ready, enjoy your meal!");
                break;
            } else {
                System.out.println("The meal isn't ready");
            }
        }

    }

}
