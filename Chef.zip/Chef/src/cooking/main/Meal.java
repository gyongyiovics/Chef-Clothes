package cooking.main;

public class Meal {
    protected String name;
    protected String intensity;
    protected String eggType;
    protected String isSalty;

    public void mealInfo(){
        System.out.println();
        System.out.println(name + ": ");
        System.out.println("----------");
        System.out.println("The intensity of the meal is: " + intensity);
        System.out.println("The egg I used for it: " + eggType);
        System.out.println("The level of saltiness is: " + isSalty);
    }

    public Meal(){};

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntensity() {
        return intensity;
    }

    public void setIntensity(String intensity) {
        this.intensity = intensity;
    }

    public String getEggType() {
        return eggType;
    }

    public void setEggType(String eggType) {
        this.eggType = eggType;
    }

    public String getIsSalty() {
        return isSalty;
    }

    public void setIsSalty(String isSalty) {
        this.isSalty = isSalty;
    }
}
