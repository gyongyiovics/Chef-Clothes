package cooking.main;
/*import cooking.ingredientsElements.Eggs;
import cooking.ingredientsElements.Ingredients;
import cooking.ingredientsElements.Vegetables;
import cooking.spicesElements.Pepper;
import cooking.spicesElements.Salt;
import cooking.spicesElements.Spices;
import cooking.toolsElements.ActionTools;
import cooking.toolsElements.WorkSpace;*/

public class Main {
    /**
     * Create a program which can handle ingredients, spices and kitchen tools.
     * Use your ingredients, spices and kitchen tools to make food!
     * Your meal should contain these ingredients!
     * Your tools and spices should have some methods to change the different states of the ingredients!
     * example:
     *      Basic lecsó
     *      Cut the paprika, tomato, onion with the knife, you might need a cutting board - myHands.wash(), myHands.wash(bowlOfVeggies), knife.cutUp(bowlOfVeggies);
     *      Put the cut onion in the frying pan with some butter
     *      Add the cut paprika and tomato
     *      Let's start cooking
     *      Add some salt and spices
     *      Put the eggs in the frying pan
     *      Wait until it's done
     *      Bon appetit
     * @param args
     */

    /** Basic lecsó recipe
     * washed myHands from the ActionTools class --> myHands.wash()
     * washed the bowlOfVeggies[] array from the Vegetables class with myHands from the ActionTools class--> myHands.wash(Vegetables[])
     * cut up the vegetables from the Ingredients class with a knife from the ActionTools class --> knife.cutUp(Vegetables[])
     * cracked the eggs from the Eggs class with myHands from the ActionTools class --> myHands.crack(Ingredients ingredient)
     * put the eggs in the bowl from the WorkSpace class --> bowl.putTheBowl(Ingredients ingredient)
     * beat up the eggs with a fork from the ActionTools class --> fork.beatenUp(Ingredients ingredient)
     * put everything in a pan from the WorkSpace class -->
     * pan.putThePan(Vegetables[] array), pan.putThePan(Spices[] array), pan.putThePan(Ingredients ingredients)
     * mix all the ingredients from the ActionTools class --> woodenSpoon.mixed(WorkSpace workSpace)
     * now, everything in the pan, so I can cook them in the stove from the ActionTools class -->
     * stove.cook(Vegetables[] vegetables), stove.cook(Ingredients ingredients)
     * serve the meal --> serveTheFood()
     * now I can check if all the ingredients are cooked or not in the Meal class --> meal.mealInfo()
     */

    /*public static void serveTheFood (Vegetables[] vegetables, Pepper pepper, Salt salt, Eggs eggs, Meal meal){

        if (vegetables[0].states.equals("cooked")&&vegetables[1].states.equals("cooked")&&vegetables[2].states.equals("cooked")&&eggs.states.equals("cooked")&&vegetables[3].states.equals("cooked")) {
            meal.setName("Lecsó");
            meal.setIntensity(pepper.getIntensity());
            meal.setEggType(eggs.getTypeOf());
            meal.setIsSalty(salt.getQuantity());
            System.out.println(meal.getName() + " is ready, enjoy your meal!");
        }else {
            System.out.println("The meal isn't ready");
        }
    }
*/
    public static void main(String[] args) {

/*        WorkSpace board = new WorkSpace("board", false, true, 10.3, "wood");

        //String name, boolean needsWire, boolean forPreparation, boolean isSharp, boolean isClean
        ActionTools myHands = new ActionTools("hands", false, true, false, true);
        ActionTools knife = new ActionTools("knife", false, true, true, true);
        ActionTools woodenSpoon = new ActionTools("wooden spoon ", false, false, false, true);
        ActionTools pot = new ActionTools("pot", false, false, false, true);

        WorkSpace bowl = new WorkSpace("bowl", false, false, 10.45, "metal");

        //String name, int quantity, String states, String color, String kind, int sweetness, boolean isHot
        Vegetables lecsoPaprika = new Vegetables("nagyFeher", 6, "raw", "white", "bogyiszloi", 11, false);
        Vegetables tomato = new Vegetables("paradicsom", 2, "raw", "red", "kerti", 5, false);
        Vegetables onion = new Vegetables("onion", 2, "raw", "purple","kerti", 2, false);
        Vegetables cukkini = new Vegetables("cukkini", 1, "raw", "green", "kerti", 1, false);


        Salt salt = new Salt("salt", "handful", "dried", "de maar");
        Paprika paprika = new Paprika("fuszerpaprika", "spoonful","dried", 10);

        Vegetables[] greens = {lecsoPaprika, tomato, onion, cukkini};

        System.out.println("First of all, let's get the knife and cut up everything: ");
        knife.cutUp(greens);

        //stir
        System.out.println("Then put everything in a bowl: ");

        //salt and spice
        bowl.addUp(salt);
        woodenSpoon.saltAll(greens);

        bowl.addUp(paprika);

        System.out.println("... and stir ...");
        woodenSpoon.stir(greens);

        //cook
        System.out.println("Finally, cook it all!");
        pot.fry(greens);

        String message = "Bon Apétit, mon Chéri!";
        System.out.println(message);*/

        /*Meal ratatouille = new Meal();

        Eggs eggs = new Eggs("chicken", "eggsy", "unbroken", 3);
        Vegetables paprika = new Vegetables("yellow", "TV", 1, false, "TVpaprika", "raw", 6);
        Vegetables tomato = new Vegetables("red", "fürtös", 2, false, "fürtöske", "raw", 6);
        Vegetables onion = new Vegetables("red", "redonion", 1, true, "hagymácska", "raw", 1);
        Vegetables hotPaprika = new Vegetables("green", "hegyeserős", 0, true, "erőspaprika", "raw", 1);

        Vegetables[] bowlOfVeggies = {paprika, tomato, onion, hotPaprika};

        Salt salt = new Salt("seaSalt", "inTheContainer", "deMaar", "spoon");
        Pepper pepper = new Pepper(2, "inTheContainer", "bors", "pinch");

        Spices[] cupOfSpice = {salt, pepper};

        ActionTools woodenSpoon = new ActionTools(false, "faKanál", false, false, true);
        ActionTools knife = new ActionTools(true, "kés", false, true, true);
        ActionTools myHands = new ActionTools(false, "kezeim", false, true, false);
        //ActionTools cuttingBoard = new ActionTools(false, "deszka", false, true, true);
        ActionTools stove = new ActionTools(false, "túzhely", true, false, true);
        ActionTools fork = new ActionTools(false, "villa", false, true, true);

        WorkSpace bowl = new WorkSpace(1.5, "plastic", "tál", false, true);
        WorkSpace pan = new WorkSpace(5, "metal", "serpenyő", false, false);

        //washed myHands from the ActionTools class --> wash()
        //washed the bowlOfVeggies[] array from the Vegetables class with myHands from the ActionTools class--> wash(Vegetables[])
        //cut up the vegetables from the Ingredients class with a knife from the ActionTools class --> cutUp(Vegetables[])
        myHands.wash();
        myHands.wash(bowlOfVeggies);
        knife.cutUp(bowlOfVeggies);

        //cracked the eggs from the Eggs class with myHands from the ActionTools class --> crack(Ingredients ingredient)
        //put the eggs in the bowl from the WorkSpace class --> putTheBowl(Ingredients ingredient)
        //beat the eggs with a fork from the ActionTools class --> beatenUp(Ingredients ingredient)
        myHands.crack(eggs);
        bowl.putTheBowl(eggs);
        fork.beatenUp(eggs);


        //put everything in a pan from the WorkSpace class -->
        // putThePan(Vegetables[] array), putThePan(Spices[] array), putThePan(Ingredients ingredients)
        pan.putThePan(cupOfSpice);
        pan.putThePan(bowlOfVeggies);
        pan.putThePan(eggs);


        //mix all the ingredients from the ActionTools class --> mixed(WorkSpace workSpace)
        woodenSpoon.mixed(pan);

        //now, everything in the pan, so I can cook them in the stove from the ActionTools class -->
        //cook(Vegetables[] ingredients), cook (Ingredients ingredients)
        stove.cook(bowlOfVeggies);
        stove.cook(eggs);


        //we can check if all the ingredients are cooked or not in the Meal class --> mealInfo()
        */
        /*if(paprika.states.equals("cooked")
                &&tomato.states.equals("cooked")
                &&onion.states.equals("cooked")
                &&eggs.states.equals("cooked")
                &&hotPaprika.states.equals("cooked")){

            ratatouille.setName("Lecsó");
            ratatouille.setIntensity(pepper.getIntensity());
            ratatouille.setEggType(eggs.getTypeOf());
            ratatouille.setIsSalty(salt.getQuantity());

            System.out.println(ratatouille.getName() + " is ready, enjoy your meal!");
        } else {
            System.out.println("The meal isn't ready...");
        }*/
        /*
        serveTheFood(bowlOfVeggies, pepper,salt, eggs, ratatouille);

        ratatouille.mealInfo();*/

        Recipe lecso = new Recipe();
        lecso.info();
        lecso.makeRecipe();
    }
}
