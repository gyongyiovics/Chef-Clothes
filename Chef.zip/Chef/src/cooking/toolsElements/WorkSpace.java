package cooking.toolsElements;

import cooking.ingredientsElements.Ingredients;
import cooking.ingredientsElements.Vegetables;
import cooking.spicesElements.Spices;

import static cooking.toolsElements.ActionTools.allInOneLine;

public class WorkSpace extends KitchenTools {
    public double size;
    public boolean inUse;

    public WorkSpace(double size, String name, boolean isWire) {
        this.size = size;
        this.inUse = false;
        this.name = name;
        this.isWire = isWire;
    }

    //put --> on the board
    public void putTheBoard(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if(array[i].states.equals("raw")){
                array[i].states = "on the board";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pot.");

        this.inUse = true;
        System.out.println("The state of " + this.name + " is now " + this.isInUse() + ".");
    }

    //put --> in the bowl
    public void putTheBowl(Ingredients ingredients){
        if(ingredients.states.equals("beaten up")){ //cracked
            ingredients.states = "in the bowl";
            System.out.println("The state of " + ingredients.name + " is now: " + ingredients.states + ".");
        }
    }

    //put --> in the pan
    public void putThePan(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if(array[i].states.equals("on the board")){
                array[i].states = "in the pan";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pan.");

        this.inUse = true;
        System.out.println("The state of " + this.name + " is now " + this.isInUse() + ".");
    }

    public void putThePan(Spices[] array){
        for (int i = 0; i < array.length; i++) {
            if(array[i].states.equals("inTheContainer")){
                array[i].states = "in the pan";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pan.");
    }

    public void putThePan(Ingredients ingredients){
        if(ingredients.states.equals("beaten up")){//in the bowl
            ingredients.states = "in the pan";
            System.out.println("The state of " + ingredients.name + " is now: " + ingredients.states + ".");
        }
    }

    //put --> in the pot
    public void putThePot(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if(array[i].states.equals("on the board")){
                array[i].states = "in the pot";
                //System.out.println("The state of " + array[i].name + " is now: " + array[i].states + ".");
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pot.");

        this.inUse = true;
        System.out.println("The state of " + this.name + " is now " + this.inUse + " .");
    }

    public void putThePot(Spices[] array){
        for (int i = 0; i < array.length; i++) {
            if(array[i].states.equals("inTheContainer")){
                array[i].states = "in the pot";
                //System.out.println("The state of " + array[i].name + " is now: " + array[i].states + ".");
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is now: in the pot.");
    }

    public void putThePot(Ingredients ingredients){
        if(ingredients.states.equals("beaten up")){//in the bowl
            ingredients.states = "in the pot";
            System.out.println("The state of " + ingredients.name + " is now: " + ingredients.states + ".");
        }
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }

    public String isInUse() {
        return this.inUse ? "used": "not in use";
    }

    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }
}
