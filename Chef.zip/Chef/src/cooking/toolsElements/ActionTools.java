package cooking.toolsElements;

import cooking.ingredientsElements.Ingredients;
import cooking.ingredientsElements.Vegetables;
import cooking.spicesElements.Spices;


public class ActionTools extends KitchenTools {
    public boolean isSharp;
    public boolean isClean;

    public ActionTools(boolean isSharp, String name, boolean isWire, boolean isClean) {
        this.name = name;
        this.isWire = isWire;
        this.isSharp = isSharp;
        this.isClean = isClean;
    }

    public void wash(){
        if(!this.isClean){
            this.isClean = true;
            System.out.println("The " + this.name + " is " + isClean() + ".");
        }
    }

    public void wash(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if(!array[i].isWashed){
                array[i].isWashed = true;
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is washed.");
    }

    public void peel(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if(!array[i].isPeeled){
                array[i].isPeeled = true;
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is peeled.");
    }

    public void cutUp(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if(!array[i].isCut){
                array[i].isCut = true;
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is cut.");
    }

    public void crack(Ingredients ingredient){
        if(ingredient.states.equals("unbroken")){
            ingredient.states = "cracked";
            System.out.println("The state of " + ingredient.name + " is now: " + ingredient.states + ".");
        }
    }

    public void beatenUp(Ingredients ingredient){
        if(ingredient.states.equals("cracked")){
            ingredient.states = "beaten up";
            System.out.println("The state of " + ingredient.name + " is now: " + ingredient.states + ".");
        }
    }

    public void mixed(WorkSpace workSpace){
        if(workSpace.inUse){
            System.out.println("The contents of the " + workSpace.name + " is mixed.");
        }
    }

    public void cook(Vegetables[] array){
        for (int i = 0; i < array.length; i++) {
            if (array[i].states.equals("in the pan")) {
                array[i].states = "cooked";
            }
        }
        System.out.print("The state of ");
        allInOneLine(array);
        System.out.println(" is cooked.");
    }

    public void cook(Ingredients ingredients){
        if(ingredients.states.equals("in the pan")){
            ingredients.states = "cooked";
            System.out.println("The state of " + ingredients.name + " is now " + ingredients.states + ".");
        }
    }

    public static void allInOneLine(Vegetables[] veggies){
        for (int i = 0; i < veggies.length; i++) {
            if(veggies[i] == veggies[veggies.length - 1]) {
                System.out.print(veggies[i].getName());
            } else {
                System.out.print(veggies[i].getName() + ", ");
            }
        }
    }

    public static void allInOneLine(Spices[] spices){
        for (int i = 0; i < spices.length; i++) {
            if(spices[i] == spices[spices.length - 1]) {
                System.out.print(spices[i].getName());
            } else {
                System.out.print(spices[i].getName() + ", ");
            }
        }
    }

    public boolean isSharp() {
        return isSharp;
    }

    public void setSharp(boolean sharp) {
        isSharp = sharp;
    }

    public String isClean() {
        if (isClean){
            return "clean";
        } else {
            return "dirty";
        }
    }

    public void setClean(boolean clean) {
        isClean = clean;
    }
}
