package cooking.spicesElements;

public class Salt extends Spices {
    protected String typeOf;

    public Salt(String states, String name, String quantity, String typeOf) {
        super(states, name, quantity);
        this.typeOf = typeOf;
    }

    public String getTypeOf() {
        return typeOf;
    }

    public void setTypeOf(String typeOf) {
        this.typeOf = typeOf;
    }
}

