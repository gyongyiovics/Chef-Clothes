package cooking.spicesElements;

public class Spices {
    public String states;
    public String name;
    public String quantity; //teaspoon, grams, ladleful, pinch

    public Spices(String states, String name, String quantity) {
        this.states = states;
        this.name = name;
        this.quantity = quantity;
    }

    public String getState() {
        return states;
    }

    public void setState(String state) {
        this.states = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return switch (quantity) {
            case "pinch" -> "Where is the salt?!";
            case "spoon" -> "Now that's what I call salty.";
            case "ladle" -> "Too salty!";
            default ->  "It's poisonous...";
        };
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}