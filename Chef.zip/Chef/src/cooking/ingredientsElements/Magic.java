package cooking.ingredientsElements;

public class Magic extends Ingredients {
    public boolean doesWork;
    public String type;

    public Magic(String name, int quantity, String type, String states, boolean doesWork) {
        this.name = name;
        this.quantity = quantity;
        this.type = type;
        this.states = states;
        this.doesWork = doesWork;
    }

    public boolean isDoesWork() {
        return doesWork;
    }

    public void setDoesWork(boolean doesWork) {
        this.doesWork = doesWork;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
