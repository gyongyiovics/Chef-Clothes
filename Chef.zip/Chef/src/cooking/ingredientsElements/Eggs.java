package cooking.ingredientsElements;

public class Eggs extends Ingredients {
    protected String typeOf;

    public Eggs(String typeOf, String name, int quantity) {
        this.typeOf = typeOf;
        this.name = name;
        this.states = "unbroken";
        this.quantity = quantity;
    }

    public String getTypeOf() {
        return this.typeOf.equals("chicken")? "chicken eggs" : "some unknown eggs";
    }

    public void setTypeOf(String typeOf) {
        this.typeOf = typeOf;
    }
}
